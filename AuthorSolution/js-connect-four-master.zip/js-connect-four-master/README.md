
# Setup
```
npm install -g livereload http-server
http-server &
livereload &
```